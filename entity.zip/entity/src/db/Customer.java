
package db;
import java.sql.*;

public class Customer 
{
        String id,name,email,address,phn;
	static Connection con1;
	static PreparedStatement stmt;

	public void setID(String id)
	{
		this.id=id;
	}
	public String getID()
	{
		return this.id;
	}

	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return this.name;
	}

	public void setEmail(String email)
	{
		this.email=email;
	}
	public String getEmail()
	{
		return this.email;
	}

	public void setPhn(String phn)
	{
		this.phn=phn;
	}
	public String getPhn()
	{
		return this.phn;
	}

	public void setAddr(String address)
	{
		this.address=address;
	}
	public String getAddr()
	{
		return this.address;
	}

	public boolean insert()
	{
		try
		{	

			ConnectionFactory.getConnection();
			con1 = ConnectionFactory.con0;
			String sql;
			sql = "insert into customer values(?,?,?,?,?)";
			stmt=con1.prepareStatement(sql);
			stmt.setString(1,getID());
                        stmt.setString(2,getName());
			stmt.setString(3,getEmail());
			stmt.setString(4,getPhn());
			stmt.setString(5,getAddr());
      		int result = stmt.executeUpdate();
      		if(result!=0)
      			return true;
      		
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{	
			try{
				con1.close();
				stmt.close();
				ConnectionFactory.closeConnection();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return false;

	}
        
        public int update(Customer c)
	{
		try
		{	
                ConnectionFactory.getConnection();
                con1 = ConnectionFactory.con0;
                String sql;
                
                sql = "update customer set cus_name='"+c.getName()+"',cus_email='"+c.getEmail()+"',cus_phn="+c.getPhn()+",cus_addr='"+c.getAddr()+"' where cus_id='"+c.getID()+"'";	
      		stmt=con1.prepareStatement(sql);
      		int r = stmt.executeUpdate();
                return r;
      				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{	
			try{
				con1.close();
				stmt.close();
				ConnectionFactory.closeConnection();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
                return 0;
	}
        
        public void delete(Customer c)
	{      
		try
		{	
			ConnectionFactory.getConnection();
			con1 = ConnectionFactory.con0;
			String sql,sql1;
                        System.out.println(c.getID());
			sql1 = "select * from customer where cus_id ='"+c.getID()+"'";
			stmt=con1.prepareStatement(sql1);
                        ResultSet rs1 = stmt.executeQuery();
                        while(rs1.next())
                        {	
                         c.setID(rs1.getString(1));
      			 c.setName(rs1.getString(2));
		         c.setEmail(rs1.getString(3));
		         c.setPhn(rs1.getString(4));
		         c.setAddr(rs1.getString(5));
			}
			rs1.close();
			sql = "delete from customer where cus_id='"+id+"'";	
                        PreparedStatement stmt1 = con1.prepareStatement(sql);
                        stmt1.execute();   
      			
      		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{	
			try{
				con1.close();
				stmt.close();
				ConnectionFactory.closeConnection();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
	}
        
	public static Customer searchByID(String id)
	{
		try
		{	Customer cusObj = new Customer();
                        
			ConnectionFactory.getConnection();
			con1 = ConnectionFactory.con0;
			String sql1;
			sql1 = "select * from customer where cus_id ='"+id+"'";
			stmt=con1.prepareStatement(sql1);
                        ResultSet rs1 = stmt.executeQuery();
                        while(rs1.next())
                        {	
                         cusObj.setID(rs1.getString(1));
      			 cusObj.setName(rs1.getString(2));
		         cusObj.setEmail(rs1.getString(3));
		         cusObj.setPhn(rs1.getString(4));
		         cusObj.setAddr(rs1.getString(5));
			}
			rs1.close();
                        return cusObj;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{	
			try{
				con1.close();
				stmt.close();
				ConnectionFactory.closeConnection();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
            return null;
	}
        


}
