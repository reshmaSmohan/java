
package db;
import java.sql.*;

public class ConnectionFactory 
{
    static final String DB_URL = "jdbc:oracle:thin:system/system@localhost";
    static final String USER = "system";
    static final String PASS = "system";
    static Connection con0;

	public static ConnectionFactory connObj = new ConnectionFactory();

	private ConnectionFactory()
	{   
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(Exception e)
		{
			System.out.println("Driver not found");
		}
	}

	public static void getConnection()
	{
		try
		{
			
	    	con0 = DriverManager.getConnection(DB_URL,USER,PASS);
	    	///System.out.println("\nConnected.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void closeConnection()
	{
		try
		{
			con0.close();
	    	//System.out.println("Connection closed..");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} 
}
